package crawler;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class JSoupWebScraper {

	public void webScrap(String attribute, ArrayList<String> urlList, String filename) throws IOException {
		
		BufferedWriter bw = new BufferedWriter(new FileWriter("src/" + filename + ".txt"));
		for (String url : urlList) {
			Document doc = Jsoup.connect(url).get();

			Elements paragraphs = doc.getElementsByTag("p");

			for (Element paragraph : paragraphs) {

				String paraText = paragraph.text();
				String sentences[] = paraText.split("\\.");
				ArrayList<Integer> indexes = new ArrayList<Integer>();
				for (int i = 0; i < sentences.length; i++) {
					if (sentences[i].toLowerCase().contains(attribute)) {
						if (i != 0) {
							indexes.add(i - 1);
						}
						indexes.add(i);
						if (i != sentences.length - 1) {
							indexes.add(i + 1);
						}
					} else {
						if (sentences[i].toLowerCase().contains("bility")
								|| sentences[i].toLowerCase().contains("bilities")
								|| sentences[i].toLowerCase().contains("ness")
								|| sentences[i].toLowerCase().contains("able")) {
							indexes.add(i);
						}
					}
				}
				for (Integer i : indexes) {
					bw.write(sentences[i]);
					bw.newLine();
				}
			}
		}
		bw.close();
	}

//	public static void main(String[] args) throws IOException {
//
//		Document doc = Jsoup.connect("https://searchsecurity.techtarget.com/definition/security").get();
//
//		Map<String, List<String>> datafromFile = new HashMap<String, List<String>>();
//		HashMap<String, Integer> freqWords = new HashMap<String, Integer>();
//
//		Elements paragraphs = doc.getElementsByTag("p");
//
//		String keyword = "security";
//		BufferedWriter bw = new BufferedWriter(new FileWriter("src/" + keyword + ".txt"));
//		for (Element paragraph : paragraphs) {
//
//			String paraText = paragraph.text();
//			String sentences[] = paraText.split("\\.");
//			ArrayList<Integer> indexes = new ArrayList<Integer>();
//			System.out.println("Sentence length: " + sentences.length);
//			for (int i = 0; i < sentences.length; i++) {
//				if (sentences[i].toLowerCase().contains(keyword)) {
//					if (i != 0) {
//						indexes.add(i - 1);
//					}
////					System.out.println("Just the sentence ============== "+sentences[i]);
//					indexes.add(i);
//					if (i != sentences.length - 1) {
//						indexes.add(i + 1);
//					}
//				} else {
//					if (sentences[i].toLowerCase().contains("bility") || sentences[i].toLowerCase().contains("bilities")
//							|| sentences[i].toLowerCase().contains("ness")
//							|| sentences[i].toLowerCase().contains("able")) {
//						indexes.add(i);
//					}
//				}
//			}
//			for (Integer i : indexes) {
//				bw.write(sentences[i]);
//				bw.newLine();
//				System.out.println(sentences[i]);
//			}
//			System.out.println("=========================================");
////			System.out.println(paragraph.text());
////			System.out.println("=========================================");
//
//		}
//		bw.close();
//	}
}
