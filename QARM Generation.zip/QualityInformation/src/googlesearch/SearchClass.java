package googlesearch;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class SearchClass {

	static String host = "https://api.cognitive.microsoft.com";
	static String path = "/bing/v7.0/search";
	static String searchTerm = "Microsoft Cognitive Services";
	private ArrayList<String> allURLs = new ArrayList<String>();
	private HashMap<String,List<String>> mapAttributeAllUrls = new HashMap<String,List<String>>();
	public String URI = "https://www.google.com/search";
	public String keyWord = "";
	public int maxNoPages = 0;
	private Matcher matcher;
	private static Pattern patternDomainName;
	private static final String DOMAIN_NAME_PATTERN = "([a-zA-Z0-9]([a-zA-Z0-9\\-]{0,61}[a-zA-Z0-9])?\\.)+[a-zA-Z]{2,6}";

	private static String query[] = new String[] { "Define OR definition OR about OR what is + Quality_Attribute",
			"Quality_Attribute + is/are",
			"Quality_Attribute + is/are + called OR defined as OR known as OR refere(s) OR described as OR formalized as", 
			"is/are + called OR defined as OR known as formalized as + Quality_Attribute",
			"Define OR definition OR about OR what is + Quality_Attribute +[in]+ Domain_Name",
			"Quality_Attribute +[in]+ Domain_Name + is/are",
			"Quality_Attribute + [in]+ Domain_Name + is/are + called OR defined as OR known as OR refere(s) OR described as OR formalized as",
			"is/are + called OR defined as OR known as formalized as + Quality_Attribute+ [in]+ Domain_Name ",
			"Feature OR Attributes OR Characteristics OR Matrix + [of] + Quality_Attribute + [in] + Domain_Name)",
			"Implement OR Development [method/scheme] OR Execution [details] OR Technique OR Operationalization OR Achieve [of] + Quality_Attribute + [in] + Domain_Name",
			"Function OR Procedure OR Algorithm OR Standard + [for] + Quality_Attribute + [in] + Domain_Name"};

	static {
		patternDomainName = Pattern.compile(DOMAIN_NAME_PATTERN);
	}
	// AIzaSyDNZLy2VmqXqjeh-C_qtxw7RolDnwV0HLM
	// AIzaSyDcp0UtDlIBaZrew0w-qDfXx3V0zq8B-MM
	
	public ArrayList<String> getallUrls(){
		return allURLs;
	}
	
	public ArrayList<String> getUrlsForAttribute(String attribute){
		return (ArrayList<String>) mapAttributeAllUrls.get(attribute);
	}
	
	public String getDomainName(String url) {

		String domainName = "";
		matcher = patternDomainName.matcher(url);
		if (matcher.find()) {
			domainName = matcher.group(0).toLowerCase().trim();
		}
		return domainName;

	}

	public void googleSearch(String query, String keywords, String domainName, int number)
			throws Exception, IOException {

//		String address = "http://ajax.googleapis.com/ajax/services/search/web?v=1.0&q=";
//		String query = "quality requirement in software";
//		String charset = "UTF-8";
//	 
//		URL url = new URL(address + URLEncoder.encode(query, charset));
//	 
//		BufferedReader in = new BufferedReader(new InputStreamReader(
//				url.openStream()));
//		String str;
//	 
//		while ((str = in.readLine()) != null) {
//			System.out.println(str);
//		}
//	 
//		in.close();

//		System.out.println("Inside ====");
		
		keywords = keywords.toLowerCase();
		ArrayList<String> urlsList = new ArrayList<String>();
		
		if (query.contains("Quality_Attribute")) {
			query = query.replace("Quality_Attribute", keywords);
		}
		if (query.contains("Domain_Name")) {
			query = query.replace("Domain_Name", domainName);
		}
		System.out.println("============== "+query+"====================");
		int count = 0;
		String google = "https://www.google.com/search?client=manjaro&channel=fs&q=";// "https://www.google.com/search?q=";
		String charset = "UTF-8";
		String userAgent = "(compatible; Googlebot/2.1; +http://www.google.com/bot.html)";// "Mozilla/5.0 ";
		Elements links = Jsoup.connect(google + URLEncoder.encode(query, charset) + "&num=" + number).timeout(0)
				.userAgent(userAgent).get().select("a[href]");
		for (Element link : links) {
			String temp = link.attr("href");
			if (!temp.startsWith("/url?q=")) {
				String urlLink = getDomainName(temp);
				continue;
			}
			String url = link.absUrl("href");
//			System.out.println("temp: " + temp);
//        	String urlLink = getDomainName(temp);
//            decode link from link of google.
//			System.out.println(url);
			String urlLink = URLDecoder.decode(url.substring(url.indexOf("=") + 1, url.indexOf("&")), charset);

			if (!urlLink.startsWith("http")) {
				continue; // ads/news etc
			}

			count++;
			allURLs.add(urlLink);
			urlsList.add(urlLink);
			System.out.println("URL (" + count + ") : " + urlLink); // link of website
			if(mapAttributeAllUrls.size()==0) {
				mapAttributeAllUrls.put(keywords, urlsList);
			}
			else {
				if(mapAttributeAllUrls.containsKey(keywords)) {
					urlsList.addAll(mapAttributeAllUrls.remove(keywords));
					mapAttributeAllUrls.put(keywords, urlsList);
				}
				else {
					mapAttributeAllUrls.put(keywords, urlsList);
				}
			}
//            googleResults.add(urlLink) ;
		}
//		String searchUrl = URI+"?q="+keywords+"&num="+number;
//		try {
//			Document doc = Jsoup.connect(searchUrl).userAgent("Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)").get();
//			Elements results = doc.select("h3.r > a");
//			for (Element result : results) {
//				String linkHref = result.attr("href");
//				String linkText = result.text();
//				System.out.println("Text::" + linkText + ", URL::" + linkHref.substring(6, linkHref.indexOf("&")));
//			}
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
	}

//	public void readWebPage(String webURL) {
//		try {
//			System.out.println("Reading web page : " + webURL);
//			URL oracle = new URL(webURL);
//			BufferedReader in = new BufferedReader(new InputStreamReader(oracle.openStream()));
//
//			String inputLine;
//			while ((inputLine = in.readLine()) != null)
//				System.out.println(inputLine);
//			in.close();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
	
	public void searchWebandGetLinks(String domainName,String filename) throws Exception {
		SearchClass sc = new SearchClass();
		ArrayList<String> attributesList = new ArrayList<String>();
		BufferedReader br = new BufferedReader(new FileReader(filename));//new BufferedReader(new FileReader("src/tesoutputfile1.txt"));
		String bufferLine = "";
		String line = "";
		while ((line = br.readLine()) != null) {
			if (line.contains("Attribute:")) {
				bufferLine = line.split(":")[1];
				if (attributesList.size() == 0) {
					attributesList.add(bufferLine.toLowerCase());
				} else if (!attributesList.contains(bufferLine.toLowerCase())) {
					attributesList.add(bufferLine.toLowerCase());
				}
			} else
				continue;
		}
		br.close();
		for (String attribute : attributesList) {
			for (int i = 1; i < query.length; i++) {
				sc.googleSearch(query[i], attribute, domainName, 100);
			}
//			break;
		}
	}
	
//	public static void main(String s[]) throws Exception {
//		SearchClass sc = new SearchClass();
//		String domainName = "Ubiquitous computing";
//		ArrayList<String> attributesList = new ArrayList<String>();
//		BufferedReader br = new BufferedReader(new FileReader("src/tesoutputfile1.txt"));
//		String bufferLine = "";
//		String line = "";
//		while ((line = br.readLine()) != null) {
//			if (line.contains("Attribute:")) {
//				bufferLine = line.split(":")[1];
//				if (attributesList.size() == 0) {
//					attributesList.add(bufferLine.toLowerCase());
//				} else if (!attributesList.contains(bufferLine.toLowerCase())) {
//					attributesList.add(bufferLine.toLowerCase());
//				}
//			} else
//				continue;
//		}
//		for (String attribute : attributesList) {
//			for (int i = 1; i < 3; i++) {
//				sc.googleSearch(query[i], attribute, domainName, 100);
//			}
//			break;
//		}
////		sc.readWebPage(sc.allURLs.get(8));
//	}
}
