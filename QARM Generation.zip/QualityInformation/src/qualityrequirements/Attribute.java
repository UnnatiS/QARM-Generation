package qualityrequirements;

import java.util.ArrayList;
import java.util.List;

public class Attribute {

	private String name = "";
	private List<String> nouns = new ArrayList<String>();
	private List<String> verbs = new ArrayList<String>();
	private List<String> adjectives = new ArrayList<String>();
	private List<String> adverbs = new ArrayList<String>();
	private List<String> synonyms = new ArrayList<String>();
	private List<String> hyponyms = new ArrayList<String>();
	private List<String> nounPhrase = new ArrayList<String>();
	private List<String> verbPhrase = new ArrayList<String>();
	
	public void printAttribute() {
		
		System.out.println("Attribute: "+name);
		System.out.println("Nouns: "+nouns.toString());
		System.out.println("adjectives: "+adjectives.toString());
		System.out.println("Verbs: "+verbs.toString());
		System.out.println("adverbs: "+adverbs.toString());
		System.out.println("synonyms: "+synonyms.toString());
		System.out.println("Hyponyms: "+hyponyms.toString());
		System.out.println("Noun Phrase: "+nounPhrase.toString());
		System.out.println("Verb Phrase: "+verbPhrase.toString());
		System.out.println("=================================================================");
	}
	
	public String getAttributeAsString() {
		String attributeString = "";
		attributeString +="\nAttribute: "+name;
		attributeString +="\nNouns: "+nouns.toString();
		attributeString +="\nadjectives: "+adjectives.toString();
		attributeString +="\nVerbs: "+verbs.toString();
		attributeString +="\nadverbs: "+adverbs.toString();
		attributeString +="\nsynonyms: "+synonyms.toString();
		attributeString +="\nHyponyms: "+hyponyms.toString();
		attributeString +="\nNoun Phrase: "+nounPhrase.toString();
		attributeString +="\nVerb Phrase: "+verbPhrase.toString();
		
		return attributeString;
	}
	
	public void setAttributeName(String name) {
		this.name = name;
	}

	public String getAttributeName() {
		return name;
	}

	public void addNoun(String noun) {
		if (nouns.size() == 0) {
			nouns.add(noun);
		} else {
			nouns.add(noun);
		}
	}
	public boolean removeNoun(String noun) {
		if(nouns.size()==0) {
			return false;
		}
		else {
			if(nouns.contains(noun)) {
				nouns.remove(noun);
				return true;
			}
			return false;
		}
	}
	public void setNouns(List<String> allNouns) {
		nouns.addAll(allNouns);
	}
	public List<String> getNouns(){
		return nouns;
	}
	
	public void addNounPhrase(String noun) {
		if (nounPhrase.size() == 0) {
			nounPhrase.add(noun);
		} else {
			nounPhrase.add(noun);
		}
	}
	public boolean removeNounPhrase(String noun) {
		if(nounPhrase.size()==0) {
			return false;
		}
		else {
			if(nounPhrase.contains(noun)) {
				nounPhrase.remove(noun);
				return true;
			}
			return false;
		}
	}
	public void setNounPhrases(List<String> allNouns) {
		nounPhrase.addAll(allNouns);
	}
	public List<String> getNounPhrases(){
		return nounPhrase;
	}
	
	public void addVerbs(String verb) {
		if (verbs.size() == 0) {
			verbs.add(verb);
		} else {
			verbs.add(verb);
		}
	}
	public boolean removeVerb(String verb) {
		if(verbs.size()==0) {
			return false;
		}
		else {
			if(verbs.contains(verb)) {
				verbs.remove(verb);
				return true;
			}
			return false;
		}
	}
	public void setVerbs(List<String> allVerbs) {
		verbs.addAll(allVerbs);
	}
	public List<String> getVerbs(){
		return verbs;
	}
	
	public void addVerbPhrase(String verb) {
		if (verbPhrase.size() == 0) {
			verbPhrase.add(verb);
		} else {
			verbPhrase.add(verb);
		}
	}
	public boolean removeVerbPhrase(String verb) {
		if(verbPhrase.size()==0) {
			return false;
		}
		else {
			if(verbPhrase.contains(verb)) {
				verbPhrase.remove(verb);
				return true;
			}
			return false;
		}
	}
	public void setVerbPhrases(List<String> allVerbs) {
		verbPhrase.addAll(allVerbs);
	}
	public List<String> getVerbPhrases(){
		return verbPhrase;
	}
	
	public void addAdjective(String adjective) {
		if (adjectives.size() == 0) {
			adjectives.add(adjective);
		} else {
			adjectives.add(adjective);
		}
	}
	public boolean removeAdjective(String adjective) {
		if(adjectives.size()==0) {
			return false;
		}
		else {
			if(adjectives.contains(adjective)) {
				adjectives.remove(adjective);
				return true;
			}
			return false;
		}
	}
	public void setAdjectives(List<String> allAdjectives) {
		verbs.addAll(allAdjectives);
	}
	public List<String> getAdjectives(){
		return adjectives;
	}
	public void addAdverb(String adverb) {
		if (adverbs.size() == 0) {
			adverbs.add(adverb);
		} else {
			adverbs.add(adverb);
		}
	}
	public boolean removeAdverb(String adverb) {
		if(adverbs.size()==0) {
			return false;
		}
		else {
			if(adverbs.contains(adverb)) {
				adverbs.remove(adverb);
				return true;
			}
			return false;
		}
	}
	public void setAdverbs(List<String> alladverbs) {
		verbs.addAll(alladverbs);
	}
	public List<String> getAdverbs(){
		return adverbs;
	}
	
	public void addSynonyms(String synonym) {
		if (synonyms.size() == 0) {
			synonyms.add(synonym);
		} else {
			synonyms.add(synonym);
		}
	}
	public void setSynonyms(List<String> allsynonym) {
		synonyms.addAll(allsynonym);
	}
	public List<String> getSynonyms(){
		return synonyms;
	}
	
	public void addHyponyms(String hyponym) {
		if (hyponyms.size() == 0) {
			hyponyms.add(hyponym);
		} else {
			hyponyms.add(hyponym);
		}
	}
	public void setHyponyms(List<String> allhyponym) {
		hyponyms.addAll(allhyponym);
	}
	public List<String> getHyponyms(){
		return hyponyms;
	}
}
