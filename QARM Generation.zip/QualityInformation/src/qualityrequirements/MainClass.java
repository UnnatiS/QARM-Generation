package qualityrequirements;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import crawler.JSoupWebScraper;
import edu.stanford.nlp.ling.CoreAnnotations.LemmaAnnotation;
import edu.stanford.nlp.ling.CoreAnnotations.NamedEntityTagAnnotation;
import edu.stanford.nlp.ling.CoreAnnotations.PartOfSpeechAnnotation;
import edu.stanford.nlp.ling.CoreAnnotations.SentencesAnnotation;
import edu.stanford.nlp.ling.CoreAnnotations.TextAnnotation;
import edu.stanford.nlp.ling.CoreAnnotations.TokensAnnotation;
import edu.stanford.nlp.ling.CoreLabel;
import edu.stanford.nlp.pipeline.Annotation;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;
import edu.stanford.nlp.semgraph.SemanticGraph;
import edu.stanford.nlp.semgraph.SemanticGraphCoreAnnotations;
import edu.stanford.nlp.trees.HeadFinder;
import edu.stanford.nlp.trees.Tree;
import edu.stanford.nlp.trees.TreeCoreAnnotations.TreeAnnotation;
import edu.stanford.nlp.util.CoreMap;
import googlesearch.SearchClass;

public class MainClass {

	static List<String> adjective = new ArrayList<>();
	static List<String> noun = new ArrayList<>();
	static List<String> verb = new ArrayList<>();
	static List<String> adverb = new ArrayList<>();
	static List<String> nounPhrase = new ArrayList<>();
	static List<String> verbPhrase = new ArrayList<>();

	
	public static void getAllPostags(String documentText) {
		Properties props = new Properties();
		props.put("annotators", "tokenize, ssplit, pos,lemma");
		StanfordCoreNLP pipeline = new StanfordCoreNLP(props);
		StopWordAnalyzer stana = new StopWordAnalyzer();
		String lemmetizedQuestion = "";
		// Create an empty Annotation just with the given text
		documentText = stana.removeStopWords(documentText);
		Annotation document = new Annotation(documentText);
		// run all Annotators on this text
		pipeline.annotate(document);
		// Iterate over all of the sentences found
		List<CoreMap> sentences = document.get(SentencesAnnotation.class);
		for (CoreMap sentence : sentences) {
			// Iterate over all tokens in a sentence
			for (CoreLabel token : sentence.get(TokensAnnotation.class)) {
				// Retrieve and add the lemma for each word into the
				// list of lemmas
				String tok = token.get(TextAnnotation.class);
				String pos = token.get(PartOfSpeechAnnotation.class);
				// JJ,JJR,JJS,NN,NNS,NNP,NNPS,POS,PRP,PRP$,RB,RBR,RBS,VB,VBD,VBG, VBN,VBP,VBZ
				// pos.contains("NN") || pos.contains("NNP") || pos.contains("JJ") ||
				// pos.contains("JJR")
//				|| pos.contains("JJS") || pos.contains("NNS") || pos.contains("NNPS") || pos.contains("POS")
//				|| pos.contains("PRP") || pos.contains("PRP$") || pos.contains("RB") || pos.contains("RBR")
//				|| pos.contains("RBS") || pos.contains("VB") || pos.contains("VBD") || pos.contains("VBG")
//				|| pos.contains("VBN") || pos.contains("VBP") || pos.contains("VBZ")
				if (pos.contains("JJ") || pos.contains("JJR") || pos.contains("JJS")) {
					adjective.add(token.get(LemmaAnnotation.class));
				}
				if (pos.contains("NN") || pos.contains("NNP") || pos.contains("NNS") || pos.contains("NNPS")
						|| pos.contains("POS")) {
					noun.add(token.get(LemmaAnnotation.class));
				}
				if (pos.contains("VB") || pos.contains("VBD") || pos.contains("VBG") || pos.contains("VBN")
						|| pos.contains("VBP") || pos.contains("VBZ")) {
					verb.add(token.get(LemmaAnnotation.class));
				}
				if (pos.contains("RB") || pos.contains("RBR") || pos.contains("RBS")) {
					adverb.add(token.get(LemmaAnnotation.class));
				}
				
			}
		}
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ArrayList<Attribute> allAttributesDoc = new ArrayList<Attribute>();
		ArrayList<Attribute> allAttributesWeb = new ArrayList<Attribute>();
		WordNetAnalyzer wordNet = new WordNetAnalyzer("src/WordNet-3.0/dict");
		try {
			
//			System.out.println(wordNet.getSynonyms("restaurant"));
			BufferedReader br = new BufferedReader(new FileReader("src/qualityinformation.txt"));
			Map<String, List<String>> datafromFile = new HashMap<String, List<String>>();
			HashMap<String, Integer> freqWords = new HashMap<String, Integer>();

			int totalAttributes = 0;
			String lineOfFile = "";
			String oneLine = "";
			List<String> tempList = new ArrayList<String>();
			while ((lineOfFile = br.readLine()) != null) {
				lineOfFile.replace("\n", " ");
				lineOfFile.replace("\n\r", " ");

				if (lineOfFile.contains("$$")) {
					tempList.add(oneLine);
					oneLine = "";
				}
				oneLine += lineOfFile + " ";

			}
			br.close();
			for (String temps : tempList) {
				temps = temps.replace("$$", " ");
				String saperated[] = temps.split(":");
				if (datafromFile.keySet().size() == 0) {
					List<String> tList = new ArrayList<String>();
					tList.add(saperated[1]);
					datafromFile.put(saperated[0], tList);
				} else {
					if (datafromFile.containsKey(saperated[0])) {
						datafromFile.get(saperated[0]).add(saperated[1]);
					} else {
						List<String> tList = new ArrayList<String>();
						tList.add(saperated[1]);
						datafromFile.put(saperated[0], tList);
					}
				}

//				System.out.println("Attribute: " + saperated[0]);
//				System.out.println("Description: " + saperated[1]);
//				System.out.println("===========================================");
			}
			BufferedWriter bw = new BufferedWriter(new FileWriter("src/tesoutputfile.txt"));
			for (Map.Entry<String, List<String>> entry : datafromFile.entrySet()) {
				System.out.println("====================================================================");
				System.out.println("Attribute: " + entry.getKey());
				Attribute attribute = new Attribute();
				attribute.setAttributeName(entry.getKey());
				totalAttributes++;
				List<String> tlistVal = entry.getValue();
				Set<String> tlistValMap = new HashSet<String>();
				noun.clear();
				verb.clear();
				adjective.clear();
				adverb.clear();
				for (String stval : tlistVal) {
					getAllPostags(stval);
					if (noun.contains(entry.getKey())) {
						noun.remove(entry.getKey());
					}
					if (verb.contains(entry.getKey())) {
						verb.remove(entry.getKey());
					}
					if (adjective.contains(entry.getKey())) {
						adjective.remove(entry.getKey());
					}
					if (adverb.contains(entry.getKey())) {
						adverb.remove(entry.getKey());
					}
					tlistValMap.addAll(noun);
					tlistValMap.addAll(adjective);
					tlistValMap.addAll(verb);
					tlistValMap.addAll(adverb);
//					tlistValMap.addAll(subjects);
					System.out.println("List of words: \n" + tlistValMap.toString());
					System.out.println("====================================================================");
				}
				attribute.setNouns(noun);
				attribute.setVerbs(verb);
				attribute.setAdjectives(adjective);
				attribute.setAdverbs(adverb);
				allAttributesDoc.add(attribute);
				Iterator value = tlistValMap.iterator();
				while (value.hasNext()) {
					String wordt = value.next().toString();
					if (freqWords.size() == 0) {
						freqWords.put(wordt, 1);
					} else {
						if (freqWords.containsKey(wordt)) {
							int cnt = freqWords.remove(wordt);
							freqWords.put(wordt, cnt + 1);
						} else {
							freqWords.put(wordt, 1);
						}

					}
				}
				bw.write("Attribute: " + entry.getKey());
				bw.newLine();
				bw.write("Description: \n" + entry.getValue().toString());
				bw.newLine();
				bw.write("===================================================================================");
				bw.newLine();
//				System.out.println("Attribute: "+entry.getKey());
//				System.out.println("Description: \n"+entry.getValue().toString());
//				System.out.println("===================================================================================");
			}
			bw.close();
			BufferedWriter bw1 = new BufferedWriter(new FileWriter("src/tesoutputfile1.txt", true));
			System.out.println("Total No. of Attributes: " + totalAttributes);
//			System.out.println("Before ========\nTotal Noun: "+noun.size()+"\tTotal Verb: "+verb.size()+"\tTotal Adjective: "+adjective.size()+"\tToal Adverb: "+adverb.size());
			for (Map.Entry<String, Integer> entryFreq : freqWords.entrySet()) {
//				System.out.println("Word : " + entryFreq.getKey() + " = " + entryFreq.getValue());
				if (entryFreq.getValue() >= (totalAttributes / 2)) {

					for (int i = 0; i < allAttributesDoc.size(); i++) {
						Attribute tAttribute = allAttributesDoc.get(i);
						if (tAttribute.removeNoun(entryFreq.getKey())) {
//							System.out.println("Removed noun");
						} else if (tAttribute.removeVerb(entryFreq.getKey())) {
//							System.out.println("Removed verb");
						} else if (tAttribute.removeAdjective(entryFreq.getKey())) {
//							System.out.println("Removed adjective");
						} else if (tAttribute.removeAdverb(entryFreq.getKey())) {
//							System.out.println("Removed adverb");
						}
					}

//					System.out.println(
//							"Word " + entryFreq.getKey() + " occures : " + entryFreq.getValue() + " \n removing it...");
//					if(noun.contains(entryFreq.getKey())) {
//						noun.remove(entryFreq.getKey());
//					}
//					if(verb.contains(entryFreq.getKey())) {
//						verb.remove(entryFreq.getKey());
//					}
//					if(adverb.contains(entryFreq.getKey())) {
//						adverb.remove(entryFreq.getKey());
//					}
//					if(adjective.contains(entryFreq.getKey())) {
//						adjective.remove(entryFreq.getKey());
//					}
				}
			}
			for (int i = 0; i < allAttributesDoc.size(); i++) {
				Attribute tAttribute = allAttributesDoc.get(i);
				for (String word : tAttribute.getNouns()) {
					allAttributesDoc.get(i).setSynonyms(wordNet.getSynonyms(word));
					allAttributesDoc.get(i).setHyponyms(wordNet.getHypernyms(word));
				}
				for (String word : tAttribute.getVerbs()) {
					allAttributesDoc.get(i).setSynonyms(wordNet.getSynonyms(word));
					allAttributesDoc.get(i).setHyponyms(wordNet.getHypernyms(word));
				}
				for (String word : tAttribute.getAdjectives()) {
					allAttributesDoc.get(i).setSynonyms(wordNet.getSynonyms(word));
					allAttributesDoc.get(i).setHyponyms(wordNet.getHypernyms(word));
				}
				for (String word : tAttribute.getAdverbs()) {
					allAttributesDoc.get(i).setSynonyms(wordNet.getSynonyms(word));
					allAttributesDoc.get(i).setHyponyms(wordNet.getHypernyms(word));
				}
			}

			for (Attribute atrb : allAttributesDoc) {
				bw1.write(atrb.getAttributeAsString());
				bw1.newLine();
//				atrb.printAttribute();
				System.out.println(atrb.getAttributeName());
			}
			bw1.close();
//			System.out.println("After ========\nTotal Noun: "+noun.size()+"\tTotal Verb: "+verb.size()+"\tTotal Adjective: "+adjective.size()+"\tToal Adverb: "+adverb.size());
		} catch (Exception e) {
			e.printStackTrace();
		}

		// WebSearch and webscrap starts here

		//websearch
		SearchClass mysearchClass = new SearchClass();
		mysearchClass.searchWebandGetLinks("Ubiquitos computing", "src/tesoutputfile1.txt");
		
		//webscraping
		JSoupWebScraper jswscrp = new JSoupWebScraper();
		for(Attribute attribute:allAttributesDoc) {
			jswscrp.webScrap(attribute.getAttributeName().toLowerCase(), mysearchClass.getUrlsForAttribute(attribute.getAttributeName().toLowerCase()), attribute.getAttributeName().toLowerCase()+"_webscrapdata");
		}
		
		//getting subQA
		
		BufferedWriter bw = new BufferedWriter(new FileWriter("src/tesoutputfileWeb.txt"));
		HashMap<String, Integer> freqWords = new HashMap<String, Integer>();
		for(Attribute attribute:allAttributesDoc) {
			
			Map<String, List<String>> datafromFile = new HashMap<String, List<String>>();
			
			
			List<String> tlistVal = new ArrayList<String>();
			Set<String> tlistValMap = new HashSet<String>();
			BufferedReader br = new BufferedReader(new FileReader("src/"+attribute.getAttributeName().toLowerCase()+"_webscrapdata.txt"));
			String line = "";
			while((line = br.readLine())!=null) {
				tlistVal.add(line);
			}
			
			noun.clear();
			verb.clear();
			adjective.clear();
			adverb.clear();
			for (String stval : tlistVal) {
				getAllPostags(stval);
				if (noun.contains(attribute.getAttributeName())) {
					noun.remove(attribute.getAttributeName());
				}
				if (verb.contains(attribute.getAttributeName())) {
					verb.remove(attribute.getAttributeName());
				}
				if (adjective.contains(attribute.getAttributeName())) {
					adjective.remove(attribute.getAttributeName());
				}
				if (adverb.contains(attribute.getAttributeName())) {
					adverb.remove(attribute.getAttributeName());
				}
				tlistValMap.addAll(noun);
				tlistValMap.addAll(adjective);
				tlistValMap.addAll(verb);
				tlistValMap.addAll(adverb);
//				tlistValMap.addAll(subjects);
				System.out.println("List of words: \n" + tlistValMap.toString());
				System.out.println("====================================================================");
			}
			attribute.setNouns(noun);
			attribute.setVerbs(verb);
			attribute.setAdjectives(adjective);
			attribute.setAdverbs(adverb);
			allAttributesWeb.add(attribute);
			Iterator value = tlistValMap.iterator();
			while (value.hasNext()) {
				String wordt = value.next().toString();
				if (freqWords.size() == 0) {
					freqWords.put(wordt, 1);
				} else {
					if (freqWords.containsKey(wordt)) {
						int cnt = freqWords.remove(wordt);
						freqWords.put(wordt, cnt + 1);
					} else {
						freqWords.put(wordt, 1);
					}

				}
			}
			bw.write("Attribute: " + attribute.getAttributeName());
			bw.newLine();
			bw.write("Description: \n" + tlistVal.toString());
			bw.newLine();
			bw.write("===================================================================================");
			bw.newLine();
		}
		bw.close();
		BufferedWriter bw1 = new BufferedWriter(new FileWriter("src/tesoutputfile1Web.txt", true));
		System.out.println("Total No. of Attributes: " + allAttributesWeb.size());
//		System.out.println("Before ========\nTotal Noun: "+noun.size()+"\tTotal Verb: "+verb.size()+"\tTotal Adjective: "+adjective.size()+"\tToal Adverb: "+adverb.size());
		for (Map.Entry<String, Integer> entryFreq : freqWords.entrySet()) {
//			System.out.println("Word : " + entryFreq.getKey() + " = " + entryFreq.getValue());
			if (entryFreq.getValue() >= (allAttributesWeb.size() / 2)) {

				for (int i = 0; i < allAttributesWeb.size(); i++) {
					Attribute tAttribute = allAttributesWeb.get(i);
					if (tAttribute.removeNoun(entryFreq.getKey())) {
//						System.out.println("Removed noun");
					} else if (tAttribute.removeVerb(entryFreq.getKey())) {
//						System.out.println("Removed verb");
					} else if (tAttribute.removeAdjective(entryFreq.getKey())) {
//						System.out.println("Removed adjective");
					} else if (tAttribute.removeAdverb(entryFreq.getKey())) {
//						System.out.println("Removed adverb");
					}
				}

//				System.out.println(
//						"Word " + entryFreq.getKey() + " occures : " + entryFreq.getValue() + " \n removing it...");
//				if(noun.contains(entryFreq.getKey())) {
//					noun.remove(entryFreq.getKey());
//				}
//				if(verb.contains(entryFreq.getKey())) {
//					verb.remove(entryFreq.getKey());
//				}
//				if(adverb.contains(entryFreq.getKey())) {
//					adverb.remove(entryFreq.getKey());
//				}
//				if(adjective.contains(entryFreq.getKey())) {
//					adjective.remove(entryFreq.getKey());
//				}
			}
		}
		for (int i = 0; i < allAttributesWeb.size(); i++) {
			Attribute tAttribute = allAttributesWeb.get(i);
			for (String word : tAttribute.getNouns()) {
				allAttributesWeb.get(i).setSynonyms(wordNet.getSynonyms(word));
				allAttributesWeb.get(i).setHyponyms(wordNet.getHypernyms(word));
			}
			for (String word : tAttribute.getVerbs()) {
				allAttributesWeb.get(i).setSynonyms(wordNet.getSynonyms(word));
				allAttributesWeb.get(i).setHyponyms(wordNet.getHypernyms(word));
			}
			for (String word : tAttribute.getAdjectives()) {
				allAttributesWeb.get(i).setSynonyms(wordNet.getSynonyms(word));
				allAttributesWeb.get(i).setHyponyms(wordNet.getHypernyms(word));
			}
			for (String word : tAttribute.getAdverbs()) {
				allAttributesWeb.get(i).setSynonyms(wordNet.getSynonyms(word));
				allAttributesWeb.get(i).setHyponyms(wordNet.getHypernyms(word));
			}
		}

		for (Attribute atrb : allAttributesWeb) {
			bw1.write(atrb.getAttributeAsString());
			bw1.newLine();
//			atrb.printAttribute();
			System.out.println(atrb.getAttributeName());
		}
		bw1.close();
		
		
	}

}